//====================
//  debug commands
//====================
//コンソール出力
function dp(message) { if (typeof console != "undefined") console.log(message); }