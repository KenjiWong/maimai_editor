//==================
// MaimaiSyncNote
//==================

var SyncEvaluate = {
	NONE: 0, 
	MISS: 1, 
	FASTGOOD: 2, 
	FASTGREAT: 3, 
	PERFECT: 4, 
	LATEGREAT: 5, 
	LATEGOOD: 6,
};
